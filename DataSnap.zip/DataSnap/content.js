chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'scrape') {
      let scrapedData = document.documentElement.outerHTML; 
      sendResponse({ data: scrapedData });
    }
  });
  