const scrapeButton = document.getElementById('scrape-button');
const downloadButton = document.getElementById('download-button');
const dataDisplay = document.getElementById('data-display');

scrapeButton.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'scrape' }, (response) => {
      dataDisplay.value = response.data;
    });
  });
});

downloadButton.addEventListener('click', () => {
    const scrapedData = dataDisplay.value;
  
    const csvContent = 'data:text/csv;charset=utf-8,' + encodeURIComponent(scrapedData);
  
    const downloadLink = document.createElement('a');
    downloadLink.setAttribute('href', csvContent);
    downloadLink.setAttribute('download', 'scraped_data.csv');
    downloadLink.style.display = 'none';
  
    document.body.appendChild(downloadLink);
    downloadLink.click();

    document.body.removeChild(downloadLink);
  });
  
